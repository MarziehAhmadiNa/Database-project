﻿namespace myapp
{
    partial class UserForm1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UserForm1));
            this.sidepanel = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.logopanel = new System.Windows.Forms.Panel();
            this.logo = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.headerpanel = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.SrcCitytxt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SrcCityBtn = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.DsCitytxt = new System.Windows.Forms.TextBox();
            this.DsCityBtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.Costtxt = new System.Windows.Forms.TextBox();
            this.CostBtn = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.Typetxt = new System.Windows.Forms.TextBox();
            this.TypeBtn = new System.Windows.Forms.Button();
            this.AllBtn = new System.Windows.Forms.Button();
            this.AvToursGrid = new System.Windows.Forms.DataGridView();
            this.RegisterBtn = new System.Windows.Forms.Button();
            this.LogOutBtn = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.YourTakenGrid = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.sidepanel.SuspendLayout();
            this.logopanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.headerpanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AvToursGrid)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YourTakenGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // sidepanel
            // 
            this.sidepanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.sidepanel.Controls.Add(this.label4);
            this.sidepanel.Controls.Add(this.label3);
            this.sidepanel.Controls.Add(this.logopanel);
            this.sidepanel.Dock = System.Windows.Forms.DockStyle.Left;
            this.sidepanel.Location = new System.Drawing.Point(0, 0);
            this.sidepanel.Name = "sidepanel";
            this.sidepanel.Size = new System.Drawing.Size(192, 517);
            this.sidepanel.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label4.Location = new System.Drawing.Point(12, 203);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(164, 256);
            this.label4.TabIndex = 6;
            this.label4.Text = "You can search by SourceCity or DestinationCity or Cost or TourType or all of the" +
    "se filters in list of Available Tours";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label3.Location = new System.Drawing.Point(12, 91);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(156, 83);
            this.label3.TabIndex = 9;
            this.label3.Text = "You can search for tours here";
            this.label3.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // logopanel
            // 
            this.logopanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.logopanel.Controls.Add(this.logo);
            this.logopanel.Controls.Add(this.pictureBox1);
            this.logopanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.logopanel.Location = new System.Drawing.Point(0, 0);
            this.logopanel.Name = "logopanel";
            this.logopanel.Size = new System.Drawing.Size(192, 69);
            this.logopanel.TabIndex = 3;
            // 
            // logo
            // 
            this.logo.AutoSize = true;
            this.logo.Font = new System.Drawing.Font("Mistral", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logo.Location = new System.Drawing.Point(82, 24);
            this.logo.Name = "logo";
            this.logo.Size = new System.Drawing.Size(94, 20);
            this.logo.TabIndex = 3;
            this.logo.Text = "Travle Agency";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(3, 3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // headerpanel
            // 
            this.headerpanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.headerpanel.Controls.Add(this.label2);
            this.headerpanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.headerpanel.Location = new System.Drawing.Point(192, 0);
            this.headerpanel.Name = "headerpanel";
            this.headerpanel.Size = new System.Drawing.Size(1104, 69);
            this.headerpanel.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label2.Location = new System.Drawing.Point(387, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(224, 25);
            this.label2.TabIndex = 0;
            this.label2.Text = "Available Tours Panel";
            // 
            // SrcCitytxt
            // 
            this.SrcCitytxt.Location = new System.Drawing.Point(366, 81);
            this.SrcCitytxt.Name = "SrcCitytxt";
            this.SrcCitytxt.Size = new System.Drawing.Size(100, 22);
            this.SrcCitytxt.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label1.Location = new System.Drawing.Point(198, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 18);
            this.label1.TabIndex = 5;
            this.label1.Text = "SourceCity";
            // 
            // SrcCityBtn
            // 
            this.SrcCityBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.SrcCityBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.SrcCityBtn.Location = new System.Drawing.Point(472, 81);
            this.SrcCityBtn.Name = "SrcCityBtn";
            this.SrcCityBtn.Size = new System.Drawing.Size(75, 23);
            this.SrcCityBtn.TabIndex = 6;
            this.SrcCityBtn.Text = "Search";
            this.SrcCityBtn.UseVisualStyleBackColor = false;
            this.SrcCityBtn.Click += new System.EventHandler(this.SrcCityBtn_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label5.Location = new System.Drawing.Point(198, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 18);
            this.label5.TabIndex = 7;
            this.label5.Text = "DestinationCity";
            // 
            // DsCitytxt
            // 
            this.DsCitytxt.Location = new System.Drawing.Point(366, 108);
            this.DsCitytxt.Name = "DsCitytxt";
            this.DsCitytxt.Size = new System.Drawing.Size(100, 22);
            this.DsCitytxt.TabIndex = 8;
            // 
            // DsCityBtn
            // 
            this.DsCityBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.DsCityBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.DsCityBtn.Location = new System.Drawing.Point(472, 108);
            this.DsCityBtn.Name = "DsCityBtn";
            this.DsCityBtn.Size = new System.Drawing.Size(75, 23);
            this.DsCityBtn.TabIndex = 9;
            this.DsCityBtn.Text = "Search";
            this.DsCityBtn.UseVisualStyleBackColor = false;
            this.DsCityBtn.Click += new System.EventHandler(this.DsCityBtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label6.Location = new System.Drawing.Point(198, 140);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 18);
            this.label6.TabIndex = 10;
            this.label6.Text = "Cost";
            // 
            // Costtxt
            // 
            this.Costtxt.Location = new System.Drawing.Point(366, 136);
            this.Costtxt.Name = "Costtxt";
            this.Costtxt.Size = new System.Drawing.Size(100, 22);
            this.Costtxt.TabIndex = 11;
            // 
            // CostBtn
            // 
            this.CostBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.CostBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.CostBtn.Location = new System.Drawing.Point(472, 135);
            this.CostBtn.Name = "CostBtn";
            this.CostBtn.Size = new System.Drawing.Size(75, 23);
            this.CostBtn.TabIndex = 12;
            this.CostBtn.Text = "Search";
            this.CostBtn.UseVisualStyleBackColor = false;
            this.CostBtn.Click += new System.EventHandler(this.CostBtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label8.Location = new System.Drawing.Point(198, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(79, 18);
            this.label8.TabIndex = 14;
            this.label8.Text = "TourType";
            // 
            // Typetxt
            // 
            this.Typetxt.Location = new System.Drawing.Point(366, 163);
            this.Typetxt.Name = "Typetxt";
            this.Typetxt.Size = new System.Drawing.Size(100, 22);
            this.Typetxt.TabIndex = 15;
            // 
            // TypeBtn
            // 
            this.TypeBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.TypeBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.TypeBtn.Location = new System.Drawing.Point(472, 162);
            this.TypeBtn.Name = "TypeBtn";
            this.TypeBtn.Size = new System.Drawing.Size(75, 23);
            this.TypeBtn.TabIndex = 16;
            this.TypeBtn.Text = "Search";
            this.TypeBtn.UseVisualStyleBackColor = false;
            this.TypeBtn.Click += new System.EventHandler(this.TypeBtn_Click);
            // 
            // AllBtn
            // 
            this.AllBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.AllBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.AllBtn.Location = new System.Drawing.Point(366, 203);
            this.AllBtn.Name = "AllBtn";
            this.AllBtn.Size = new System.Drawing.Size(118, 51);
            this.AllBtn.TabIndex = 17;
            this.AllBtn.Text = "Search by all filters";
            this.AllBtn.UseVisualStyleBackColor = false;
            this.AllBtn.Click += new System.EventHandler(this.AllBtn_Click);
            // 
            // AvToursGrid
            // 
            this.AvToursGrid.BackgroundColor = System.Drawing.Color.White;
            this.AvToursGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AvToursGrid.Location = new System.Drawing.Point(748, 112);
            this.AvToursGrid.Name = "AvToursGrid";
            this.AvToursGrid.RowTemplate.Height = 24;
            this.AvToursGrid.Size = new System.Drawing.Size(524, 370);
            this.AvToursGrid.TabIndex = 18;
            // 
            // RegisterBtn
            // 
            this.RegisterBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.RegisterBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.RegisterBtn.Location = new System.Drawing.Point(366, 465);
            this.RegisterBtn.Name = "RegisterBtn";
            this.RegisterBtn.Size = new System.Drawing.Size(118, 40);
            this.RegisterBtn.TabIndex = 19;
            this.RegisterBtn.Text = "Register";
            this.RegisterBtn.UseVisualStyleBackColor = false;
            this.RegisterBtn.Click += new System.EventHandler(this.RegisterBtn_Click);
            // 
            // LogOutBtn
            // 
            this.LogOutBtn.BackColor = System.Drawing.Color.WhiteSmoke;
            this.LogOutBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.LogOutBtn.Location = new System.Drawing.Point(513, 465);
            this.LogOutBtn.Name = "LogOutBtn";
            this.LogOutBtn.Size = new System.Drawing.Size(118, 40);
            this.LogOutBtn.TabIndex = 20;
            this.LogOutBtn.Text = "LogOut";
            this.LogOutBtn.UseVisualStyleBackColor = false;
            this.LogOutBtn.Click += new System.EventHandler(this.LogOutBtn_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label7.Location = new System.Drawing.Point(228, 275);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 18);
            this.label7.TabIndex = 21;
            this.label7.Text = "Your Tours";
            // 
            // YourTakenGrid
            // 
            this.YourTakenGrid.BackgroundColor = System.Drawing.Color.White;
            this.YourTakenGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.YourTakenGrid.Location = new System.Drawing.Point(214, 306);
            this.YourTakenGrid.Name = "YourTakenGrid";
            this.YourTakenGrid.RowTemplate.Height = 24;
            this.YourTakenGrid.Size = new System.Drawing.Size(509, 153);
            this.YourTakenGrid.TabIndex = 22;
            this.YourTakenGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.label9.Location = new System.Drawing.Point(759, 81);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(123, 18);
            this.label9.TabIndex = 23;
            this.label9.Text = "Available Tours";
            // 
            // UserForm1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1296, 517);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.YourTakenGrid);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.LogOutBtn);
            this.Controls.Add(this.RegisterBtn);
            this.Controls.Add(this.AvToursGrid);
            this.Controls.Add(this.AllBtn);
            this.Controls.Add(this.TypeBtn);
            this.Controls.Add(this.Typetxt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.CostBtn);
            this.Controls.Add(this.Costtxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.DsCityBtn);
            this.Controls.Add(this.DsCitytxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.SrcCityBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SrcCitytxt);
            this.Controls.Add(this.headerpanel);
            this.Controls.Add(this.sidepanel);
            this.Name = "UserForm1";
            this.Text = "UserForm1";
            this.Load += new System.EventHandler(this.UserForm1_Load);
            this.sidepanel.ResumeLayout(false);
            this.logopanel.ResumeLayout(false);
            this.logopanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.headerpanel.ResumeLayout(false);
            this.headerpanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AvToursGrid)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YourTakenGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel sidepanel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel logopanel;
        private System.Windows.Forms.Label logo;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel headerpanel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox SrcCitytxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button SrcCityBtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox DsCitytxt;
        private System.Windows.Forms.Button DsCityBtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox Costtxt;
        private System.Windows.Forms.Button CostBtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox Typetxt;
        private System.Windows.Forms.Button TypeBtn;
        private System.Windows.Forms.Button AllBtn;
        private System.Windows.Forms.DataGridView AvToursGrid;
        private System.Windows.Forms.Button RegisterBtn;
        private System.Windows.Forms.Button LogOutBtn;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DataGridView YourTakenGrid;
        private System.Windows.Forms.Label label9;
    }
}